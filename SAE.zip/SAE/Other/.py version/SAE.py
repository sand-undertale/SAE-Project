print("Nova McNeal SAE Project v.1.0.1.")
print("1. FFA History.")
print("2. AG History.")
print("3. FFA Meaning.")
print("4. AG Meaning.")
print("5. Why Is FFA important?")
print("6. Why is AG Important?")
choice = int(input("Enter your choice: "))
if choice == 1:
    print(
        "The National FFA Organization was founded in 1928. It began as an organization for boys interested in farming but has since evolved into an inclusive student organization promoting agricultural education. The FFA aims to develop students' leadership, personal growth, and career success through agricultural education."
    )
if choice == 2:
    print(
        "From 1700 to 2024, U.S. farming went from small farms growing crops like tobacco and cotton to larger, more efficient operations. New tools and machines, like the cotton gin and tractors, helped farmers increase production. Today, farming uses high-tech equipment and focuses on sustainability while feeding the world."
    )
if choice == 3:
    print("Future Farmers of America.")
if choice == 4:
    print("Agriculture, eg. farming, fishing, etc.")
if choice == 5:
    print(
        "FFA is important so young, inspiring farmers can be educated on what they want to me when they grow up."
    )
if choice == 6:
    print(
        "Agriculture is important becuase it is one if the main sources of food in our modren world, it's how all of our crops, meat, and materials are farmed/created."
    )
input()